﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jahresprojekt_2IT
{
    public class Knight_class
    {
        private int _leben, _speed;
        public bool left, right, jumping, doubleJump;
        public int high, jump;


        #region getter/setter

        public int leben
        {
            get
            {
                return _leben;
            }

            set
            {
                _leben = value;
            }
        }

        public int speed
        {
            get
            {
                return _speed;
            }

            set
            {
                _speed = value;
            }
        }

        #endregion


        #region Constructors
        public Knight_class()
        {

        }

        public Knight_class(int speed, int leben)
        {
            this.speed = speed;
            this.leben = leben;
        }
        public Knight_class(int jump, int high, int leben, int speed)
        {
            this.jump = jump;
            this.high = high;
            this.leben = leben;
            this.speed = speed;
        }

        #endregion

        public void DoubleJump()
        {
            if (doubleJump == true && high < 0)
            {
                doubleJump = false;
            }
            if (doubleJump == true)
            {
                jump = -20;
                high -= 1;
            }
            else
            {
                jump = 16;
            }
        }
        // jumping
        public void KeysUP()
        {
            if (jumping == true && high < 0)
            {
                jumping = false;
            }
            if (jumping == true)
            {
                jump = -10;
                high -= 1;
            }
            else
            {
                jump = 16;
            }
        }
    }


}