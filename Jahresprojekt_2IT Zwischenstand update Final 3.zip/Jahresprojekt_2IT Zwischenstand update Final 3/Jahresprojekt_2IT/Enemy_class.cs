﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jahresprojekt_2IT
{
    internal class Enemy_class
    {
        private int _leben, _speed;

        private Label healthLabel;
        #region getter/setter
        public int leben
        {
            get 
            { 
                return _leben; 
            }

            set 
            { 
                _leben = value;
                if (healthLabel != null)
                {
                    healthLabel.Text = _leben.ToString();
                }
            }
        }


        public int speed
        {
            get 
            { 
                return _speed; 
            }

            set 
            {
                _speed = value; 
            }
        }
        #endregion


        #region Constructors
        public Enemy_class()
        {
        }

        public Enemy_class(int speed)
        {
            this.speed = speed;
        }
        #endregion
        public Label HealthLabel
        {
            get { return healthLabel; }
            set { healthLabel = value; }
        }

    }
}
