﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jahresprojekt_2IT
{
    public partial class Stage2 : Form
    {
        string KW = "N";
        bool isFinished = false;
        //player
        Knight_class knightObject = new Knight_class(7, 5);
        //enemy
        Enemy_class enemyObject1 = new Enemy_class(4);
        Enemy_class enemyObject2 = new Enemy_class(7);
        private bool blow = false;
        public Stage2()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            knightObject.KeysUP();
        }
        private async void GameTimer(object sender, EventArgs e)
        {
            // tells you your lifes
            Leben.Text = "Leben: " + knightObject.leben;
            player.Top += knightObject.jump;
            //Sword.Left = player.Left;

            //knightObject.KeysUP();

            //moves player to the left
            if (knightObject.left == true)
            {
                player.Left -= knightObject.speed;
            }
            if (KW.Equals("W"))
            {
                knightObject.KeysUP();
            }
            else if (KW.Equals("E"))
            {
                knightObject.DoubleJump();
            }
            // moves player to the right
            if (knightObject.right == true)
            {
                player.Left += knightObject.speed;
            }



            // checks if player is standing on a platform
            foreach (Control p in Controls)
            {
                if (p is PictureBox)
                {
                    if ((string)p.Tag == "platform")
                    {
                        if (player.Bounds.IntersectsWith(p.Bounds))
                        {
                            knightObject.high = 8;
                            player.Top = p.Top - player.Height;
                        }

                    }
                }
            }
            // damage from enemies
            foreach (Control en in Controls)
            {
                if ((string)en.Tag == "enemy")
                {
                    if (player.Bounds.IntersectsWith(en.Bounds))
                    {
                        if ((Sword.Height >= 12 && Sword.Height <= 20) && en.Name == enemy1.Name)
                        {
                            enemy1.Dispose();
                        }
                        else if (Sword.Height == 12 && Sword.Width == 28 && en.Name == enemy2.Name)
                        {
                            enemy2.Dispose();
                        }
                        else if (Sword.Height == 12 && Sword.Width == 28 && en.Name == enemy3.Name)
                        {
                            enemy3.Dispose();
                        }
                        else if (Sword.Height == 12 && Sword.Width == 28 && en.Name == enemy4.Name)
                        {
                            enemy4.Dispose();
                        }
                        else
                        {
                            knightObject.leben = knightObject.leben - 1;
                            Leben.Text = "Leben: " + knightObject.leben;
                            player.Top = 202;
                            player.Left = 66;
                        }
                    }
                }
            }
            // damage from lava
            foreach (Control l in Controls)
            {
                if ((string)l.Tag == "lava")
                {
                    if (player.Bounds.IntersectsWith(l.Bounds))
                    {
                        knightObject.leben = knightObject.leben - 2;
                        Leben.Text = "Leben: " + knightObject.leben;
                        player.Top = 202;
                        player.Left = 66;
                    }
                }
            }


            // to detect if player has reached the end of stage 1
            foreach (Control f in Controls)
            {
                if ((string)f.Tag == "finish")
                {
                    if (player.Bounds.IntersectsWith(f.Bounds))
                    {
                        isFinished = true;
                        break;
                    }
                }
            }
            if (isFinished)
            {
                timer1.Stop();
                MessageBox.Show("STAGE 2 CLEARED.");
                Stage3 obs = new Stage3();
                obs.Show();
                this.Hide();
            }

            // when the lifes go below 0 you die and have to reset
            if (knightObject.leben <= 0)
            {
                timer1.Stop();
                Leben.Text = "GAME OVER";
            }


            // when enemies get to the edge they will turn around and go the other direction until they hit another edge
            enemy1.Left -= enemyObject1.speed;

            if (enemy1.Left < pictureBox3.Left || enemy1.Left + enemy1.Width > pictureBox3.Left + pictureBox3.Width)
            {
                enemyObject1.speed = -enemyObject1.speed;
            }

            enemy2.Left -= enemyObject1.speed;

            if (enemy2.Left < pictureBox6.Left || enemy2.Left + enemy2.Width > pictureBox6.Left + pictureBox6.Width)
            {
                enemyObject1.speed = -enemyObject1.speed;
            }
            
            enemy3.Left += enemyObject1.speed;
            if (enemy3.Left < pictureBox3.Left || enemy3.Left + enemy3.Width > pictureBox3.Left + pictureBox3.Width)
            {
                enemyObject1.speed = +enemyObject1.speed;
            }
            enemy4.Left -= enemyObject1.speed;
            if (enemy4.Left < pictureBox4.Left || enemy4.Left + enemy4.Width > pictureBox4.Left + pictureBox4.Width)
            {
                enemyObject1.speed = -enemyObject1.speed;
            }
            if (enemy5.Top == 0)
            {                
                blow = false;
            }
            else if (enemy5.Top == 292)
            {
                blow = true;
            }
            if (blow)
            {
                enemy5.Top -= 1;
            }
            else if (!blow)
            {
                enemy5.Top += 1;
            }

            //enemy5.Top -= 1;



            //if (enemy5.Left < pictureBox8.Left || enemy5.Left + enemy5.Width > pictureBox8.Left + pictureBox8.Width)
            //{
            //    enemyObject1.speed = -enemyObject1.speed;
            //}

            // for the sword to move with the player
            /*
             Sword.Location = player.Location;
             Sword.Top += 1;
             Sword.Left += 35;
            */
            var x = player.Location;
            x.X += 30;
            Sword.Location = x;
        }
        private void Up(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                knightObject.left = false;
            }

            if (e.KeyCode == Keys.J)
            {
                if (Sword.Width == 28 && Sword.Height == 12)
                {
                    Sword.Height = 28;
                    Sword.Width = 12;
                }
            }
            if (e.KeyCode == Keys.K)
            {
                knightObject.speed = 2;
            }
            
            if (e.KeyCode == Keys.D)
            {
                knightObject.right = false;
            }


            // if player isn't on the ground he can't jump
            if (e.KeyCode == Keys.W && knightObject.jumping == false)
            {
                knightObject.jumping = true;
                KW = "W";
            }



            //  when you press "Enter" it will reset the stage
            if (e.KeyCode == Keys.Enter)
            {
                ResetGame();
            }

        }

        // when the key "A" or "D" is pressed down move right or left
        private void Down(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                knightObject.left = true;
            }

            if (e.KeyCode == Keys.K)
            {
                knightObject.speed = 7;
            }

            if (e.KeyCode == Keys.D)
            {
                knightObject.right = true;
            }
            if (e.KeyCode == Keys.E)
            {
                knightObject.doubleJump = true;
                KW = "E";
            }

            // normal jump
            //if (e.KeyCode == Keys.W && knightObject.jumping == false)
            //{
            //    if (!knightObject.jumping)
            //    {
            //        knightObject.high = 10;
            //    }


            //double jump doesn't work (you can jump infinit), i will try to do it with a while/do-while loop (if it doens't work i will have to find another solution)


            // I just played around and looked what would happen, I already knew it wouldn't work but I just wanted to test a bit
            /*else if (!k.doubleJump)
             {

              k.high = -10;
              k.doubleJump = true;
            }*/
            //}
            //else if (e.KeyCode == Keys.W && knightObject.jumping == true)
            //{
            //    if (knightObject.jumping && knightObject.doubleJump == false)
            //    {
            //        knightObject.high = 10;
            //        knightObject.doubleJump = true;
            //    }
            //}
        }

        // when you press "Enter" you need this Methode which resets everything in the stage
        private void ResetGame()
        {
            knightObject.jumping = false;
            knightObject.doubleJump = false;
            knightObject.left = false;
            knightObject.right = false;
            knightObject.leben = 5;
            timer1.Start();



            //resets player position
            player.Top = 202;
            player.Left = 80;

            //resets enemy position
            enemy1.Left = 612;
            enemy2.Left = 1222;
            enemy3.Left = 494;
            enemy4.Left = 825;
            enemy5.Left = 465;
            Sword.Top = 150;
            Sword.Left = 100;
        }

        private void Stage2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar == 106)
            {
                if (Sword.Width == 12 && Sword.Height == 28)
                {
                    Sword.Height = 12;
                    Sword.Width = 28;
                }
            }
        }
    }
}
